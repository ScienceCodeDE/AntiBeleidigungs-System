-=-=- AntiBleidigungsSystem -=-=-

H�chstwarscheinlich wirst du jetzt 2 Jar Datein im Komprmierten Ordner haben.

--> AntiBeleidigungsSystem ist das Haupt-Plugin und geh�rt in den BungeeCord Plugins Ordner [\plugins]

--> AntiSpam ist das Neben-Plugin und kann auf jeden Spigot Server drauf. [\plugins]


==========>
Vorrausetzungen f�r das AntiBeleidigungsSystem:

- BungeeCord 1.8.8
- Gen�gend RAM
- Ein Bungee Permissions System [Ich empfehle: https://www.youtube.com/watch?v=Wc454qJkmFM]

-=-=-=-

Vorrausetzungen f�r das AntiSpam Plugin:

- Spigot 1.8.8
- Gen�gend RAM
- Ein Permissions System zB. PermissionsEx

========>

Permissions [AntiBeleidigungsSystem]:

- chat.notify - Mit dieser Permissions k�nnen zB. Sups sehen wenn ein Spieler versucht hat eine Beleidigung zu schreiben.

- chat.bypass - Mit dieser Permission kann man das System �berwinden bzw. man wird vom System nicht geblockt.
			
=======>

Permissions [AntiSpam]:

- antispam.bypass - Mit dieser Permission wird man nicht vom AntiSpam System aufgehalten!

======>

Plugin coded by ScienceCode
Version: 3.0